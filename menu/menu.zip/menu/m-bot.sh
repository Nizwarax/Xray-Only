#!/bin/bash
clear
y='\033[1;33m'
BGX="\033[42m"
CYAN="\033[96m"
Putih="\033[97m"
RED='\033[0;31m'
NC='\033[0m'
green='\033[0;32m'
BIBlack='\033[1;90m'
BIGreen='\033[1;92m'
BIYellow='\033[1;93m'
BIBlue='\033[1;94m'
BIPurple='\033[1;95m'
BICyan='\033[1;96m'
BIWhite='\033[1;97m'
UWhite='\033[4;37m'
On_IPurple='\033[0;105m'
On_IRed='\033[0;101m'
IBlack='\033[0;90m'
IGreen='\033[0;92m'
IYellow='\033[0;93m'
IBlue='\033[0;94m'
IPurple='\033[0;95m'
ICyan='\033[0;96m'
IWhite='\033[0;97m'
GREENBO='\033[1;32m'
bgwhite='\e[40;97;1m'
bgred='\e[41;97;1m'
bggreen='\e[42;97;1m'
bgyellow='\e[43;97;1m'
bgmagenta='\e[45;97;1m'
bgblue='\e[46;97;1m'
bgblack='\e[47;30;1m'
w='\033[97m'
ORANGE='\033[0;34m'
clear
echo -e "${BIWhite}──────────────────────────────────────${NC}"
echo -e "${BIYellow}BOT MANAGER${NC}"
echo -e "${BIWhite}──────────────────────────────────────${NC}"
echo -e "${IGreen}[${BIWhite}01${IGreen}] ${NC}${BIWhite}Bot Private${NC}"
echo -e "${IGreen}[${BIWhite}02${IGreen}] ${NC}${BIWhite}Bot Give${NC}"
echo -e "${IGreen}[${BIWhite}03${IGreen}] ${NC}${BIWhite}Bot Sellvpn${NC}"
echo -e "${BIWhite}──────────────────────────────────────${NC}"
echo -e "${BIYellow}Input x or [ Ctrl+C ] • To-${BIWhite}Exit${NC}"
echo -e "${BIWhite}──────────────────────────────────────${NC}"
echo ""
read -p "Select menu :" opt
echo -e ""
case $opt in
1) clear ; m-private ;;
2) clear ; m-give ;;
3) clear ; m-sellvpn ;;
0) clear ; menu ; exit ;;
x) clear ; menu ;;
*) echo "anda salah tekan" ; sleep 1 ; m-bot ;;
esac